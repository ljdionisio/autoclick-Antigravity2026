
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { TargetButton, LogEntry, SystemMetrics } from './types';
import { 
  Activity, 
  ShieldAlert, 
  ShieldCheck, 
  Wifi, 
  WifiOff, 
  Target, 
  Settings, 
  Play, 
  Pause, 
  Terminal, 
  Eye, 
  MousePointer2,
  Lock,
  FileCode,
  Zap
} from 'lucide-react';

const INITIAL_TARGETS: TargetButton[] = [
  { id: '1', name: 'Aceitar Alteração', triggerText: 'Accept', color: '#2563EB', confidenceThreshold: 0.92, shortcut: '⌘+Enter', status: 'active' },
  { id: '2', name: 'Rejeitar Alteração', triggerText: 'Reject', color: '#DC2626', confidenceThreshold: 0.95, shortcut: '⌘+Backspace', status: 'inactive' },
  { id: '3', name: 'Commit Preparado', triggerText: 'Commit', color: '#10B981', confidenceThreshold: 0.98, shortcut: '⌘+K', status: 'active' },
];

const App: React.FC = () => {
  // State
  const [isScanning, setIsScanning] = useState(false);
  const [targets, setTargets] = useState<TargetButton[]>(INITIAL_TARGETS);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [metrics, setMetrics] = useState<SystemMetrics>({
    totalClicks: 1402,
    uptime: '04:12:33',
    filesChangedCurrentBatch: 0,
    bridgeStatus: 'disconnected',
    safetyLockActive: false,
  });

  const logsEndRef = useRef<HTMLDivElement>(null);
  const wsRef = useRef<WebSocket | null>(null);

  // Helper to add logs
  const addLog = useCallback((type: LogEntry['type'], message: string) => {
    setLogs(prev => [
      ...prev.slice(-49), // Keep last 50 logs
      {
        id: Math.random().toString(36).substr(2, 9),
        timestamp: new Date().toLocaleTimeString('pt-BR', { hour12: false, hour: '2-digit', minute:'2-digit', second:'2-digit' }),
        type,
        message
      }
    ]);
  }, []);

  // Scroll logs to bottom
  useEffect(() => {
    logsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  // WebSocket Connection Mock/Real Logic
  useEffect(() => {
    const connectBridge = () => {
      setMetrics(m => ({ ...m, bridgeStatus: 'connecting' }));
      addLog('info', 'Tentando handshake com Ponte Python Local (ws://localhost:8765)...');
      
      // Simulate connection for UI demo purposes since we don't have the python server running
      setTimeout(() => {
        // In a real scenario, this would be new WebSocket('ws://localhost:8765');
        // For demo:
        setMetrics(m => ({ ...m, bridgeStatus: 'connected' }));
        addLog('bridge', 'Conectado à Ponte de Entrada do SO Local. Latência: 4ms');
      }, 1500);
    };

    connectBridge();

    return () => {
      // Cleanup
      if (wsRef.current) wsRef.current.close();
    };
  }, [addLog]);

  // Safety Lock Logic & Simulation Loop
  useEffect(() => {
    if (!isScanning || metrics.safetyLockActive) return;

    const interval = setInterval(() => {
      // Randomly simulate file changes detection
      const detectedChanges = Math.floor(Math.random() * 8); // 0 to 7 files
      
      // Update metrics
      setMetrics(prev => {
        // Check Safety Lock Condition
        if (detectedChanges > 5) {
          addLog('error', `TRAVA DE SEGURANÇA ACIONADA: ${detectedChanges} arquivos alterados simultaneamente. Autonomia pausada.`);
          setIsScanning(false);
          return {
            ...prev,
            filesChangedCurrentBatch: detectedChanges,
            safetyLockActive: true
          };
        }

        // If safe, simulate a click
        if (Math.random() > 0.6) {
           addLog('success', `Alvo 'Aceitar Alteração' detectado (98%). Enviando (x:1204, y:840) para ponte.`);
           return {
             ...prev,
             filesChangedCurrentBatch: detectedChanges,
             totalClicks: prev.totalClicks + 1
           };
        }

        return { ...prev, filesChangedCurrentBatch: detectedChanges };
      });

    }, 2000);

    return () => clearInterval(interval);
  }, [isScanning, metrics.safetyLockActive, addLog]);

  const toggleScanning = () => {
    if (metrics.safetyLockActive) {
      // Reset lock
      setMetrics(m => ({ ...m, safetyLockActive: false, filesChangedCurrentBatch: 0 }));
      addLog('warning', 'Trava de Segurança substituída manualmente pelo usuário.');
    }
    setIsScanning(!isScanning);
    addLog('info', !isScanning ? 'Sequência de varredura visual iniciada.' : 'Sequência de varredura interrompida.');
  };

  return (
    <div className="flex h-screen bg-[#020617] text-slate-300 font-light overflow-hidden">
      
      {/* Sidebar */}
      <aside className="w-72 glass-panel flex flex-col border-r border-slate-800/50 z-20">
        <div className="p-6 border-b border-slate-800/50">
          <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
            <Zap className="w-5 h-5 text-blue-500 fill-blue-500/20" />
            ANTIGRAVITY <span className="text-blue-500 text-xs align-top font-normal border border-blue-500/30 rounded px-1 ml-1">V5.0</span>
          </h1>
          <p className="text-xs text-slate-500 mt-2 font-medium">Centro de Automação de IDE</p>
        </div>

        <nav className="flex-1 p-4 space-y-2">
          <div className="flex items-center gap-3 px-4 py-3 bg-blue-600/10 text-blue-400 rounded-lg border border-blue-500/20 cursor-pointer">
            <Activity className="w-5 h-5" />
            <span className="font-medium">Painel</span>
          </div>
          <div className="flex items-center gap-3 px-4 py-3 text-slate-400 hover:bg-slate-800/50 hover:text-slate-200 rounded-lg cursor-pointer transition-colors">
            <Target className="w-5 h-5" />
            <span>Biblioteca de Alvos</span>
          </div>
          <div className="flex items-center gap-3 px-4 py-3 text-slate-400 hover:bg-slate-800/50 hover:text-slate-200 rounded-lg cursor-pointer transition-colors">
            <FileCode className="w-5 h-5" />
            <span>Padrões</span>
          </div>
          <div className="flex items-center gap-3 px-4 py-3 text-slate-400 hover:bg-slate-800/50 hover:text-slate-200 rounded-lg cursor-pointer transition-colors">
            <Settings className="w-5 h-5" />
            <span>Configuração</span>
          </div>
        </nav>

        <div className="p-4 border-t border-slate-800/50">
          <div className={`p-4 rounded-xl border ${metrics.bridgeStatus === 'connected' ? 'bg-emerald-950/20 border-emerald-500/30' : 'bg-slate-900 border-slate-800'}`}>
            <div className="flex justify-between items-center mb-2">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">Status da Ponte</span>
              {metrics.bridgeStatus === 'connected' ? <Wifi className="w-4 h-4 text-emerald-500" /> : <WifiOff className="w-4 h-4 text-slate-500" />}
            </div>
            <div className={`text-sm font-medium ${metrics.bridgeStatus === 'connected' ? 'text-emerald-400' : 'text-slate-400'}`}>
              {metrics.bridgeStatus === 'connected' ? 'WS::Conectado' : metrics.bridgeStatus === 'connecting' ? 'WS::Conectando...' : 'WS::Desconectado'}
            </div>
            <div className="text-[10px] text-slate-600 mt-1 truncate">
              ws://localhost:8765
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col relative">
        {/* Top Header */}
        <header className="h-20 border-b border-slate-800/50 glass-panel flex justify-between items-center px-8 z-10">
          <div className="flex items-center gap-6">
             <div className="flex flex-col">
               <span className="text-xs text-slate-500 uppercase font-bold tracking-widest">Workspace Ativo</span>
               <span className="text-lg text-white font-medium">Janela VSCode / Agente Cursor</span>
             </div>
             <div className="h-8 w-px bg-slate-800"></div>
             <div className="flex gap-4">
                <div className="flex flex-col">
                    <span className="text-[10px] text-slate-500">TEMPO ATIVO</span>
                    <span className="font-mono text-slate-300">{metrics.uptime}</span>
                </div>
                <div className="flex flex-col">
                    <span className="text-[10px] text-slate-500">CLIQUES TOTAIS</span>
                    <span className="font-mono text-blue-400">{metrics.totalClicks.toLocaleString()}</span>
                </div>
             </div>
          </div>

          <div className="flex items-center gap-4">
            {metrics.safetyLockActive && (
              <div className="flex items-center gap-2 px-4 py-2 bg-red-500/10 border border-red-500/50 rounded-full text-red-500 animate-pulse">
                <Lock className="w-4 h-4" />
                <span className="text-xs font-bold uppercase tracking-wide">Trava de Segurança Ativa</span>
              </div>
            )}
            
            <button 
              onClick={toggleScanning}
              className={`flex items-center gap-3 px-6 py-2.5 rounded-lg font-semibold transition-all duration-300 ${
                metrics.safetyLockActive 
                  ? 'bg-red-600 hover:bg-red-700 text-white shadow-lg shadow-red-900/40' 
                  : isScanning 
                    ? 'bg-amber-500/10 text-amber-500 border border-amber-500/50 hover:bg-amber-500/20' 
                    : 'bg-blue-600 hover:bg-blue-500 text-white shadow-lg shadow-blue-900/40 neon-glow'
              }`}
            >
              {metrics.safetyLockActive ? 'REINICIAR' : isScanning ? <><Pause className="w-4 h-4 fill-current" /> PAUSAR AUTO</> : <><Play className="w-4 h-4 fill-current" /> ATIVAR AUTO</>}
            </button>
          </div>
        </header>

        {/* Dashboard Grid */}
        <div className="flex-1 p-8 grid grid-cols-12 gap-6 overflow-y-auto">
          
          {/* Visual Monitor Area */}
          <div className="col-span-8 flex flex-col gap-6">
            <div className="bg-slate-900/50 border border-slate-800 rounded-2xl p-1 relative overflow-hidden h-[400px] group">
               {/* Decorative header for monitor */}
               <div className="absolute top-4 left-4 z-10 flex gap-2">
                 <div className="bg-black/40 backdrop-blur px-2 py-1 rounded border border-white/10 text-[10px] text-white font-mono">
                    CAM_01: AO VIVO
                 </div>
                 {isScanning && (
                   <div className="bg-red-500/80 backdrop-blur px-2 py-1 rounded text-[10px] text-white font-bold animate-pulse">
                     GRAVANDO
                   </div>
                 )}
               </div>

               {/* Simulated Screen Content */}
               <div className="w-full h-full bg-[#0B1121] rounded-xl relative flex items-center justify-center overflow-hidden">
                  <div className="absolute inset-0 opacity-20 grid grid-cols-[repeat(20,minmax(0,1fr))] grid-rows-[repeat(12,minmax(0,1fr))]">
                    {Array.from({ length: 240 }).map((_, i) => (
                      <div key={i} className="border-[0.5px] border-slate-700/30"></div>
                    ))}
                  </div>

                  {/* Scan Line Animation */}
                  {isScanning && !metrics.safetyLockActive && <div className="scan-line z-0"></div>}

                  {/* Placeholder Message */}
                  <div className="text-center z-10">
                    <Eye className={`w-12 h-12 mx-auto mb-4 ${isScanning ? 'text-blue-500' : 'text-slate-700'}`} />
                    <h3 className="text-slate-400 font-light text-lg">Buffer de Quadros do Córtex Visual</h3>
                    <p className="text-slate-600 text-sm mt-2 max-w-md mx-auto">
                      Aguardando fluxo de quadros da Ponte WebSocket...
                      <br/>
                      <span className="font-mono text-xs text-slate-700 mt-2 block">Carregando...</span>
                    </p>
                  </div>

                  {/* Simulated Detected Target Overlay */}
                  {isScanning && !metrics.safetyLockActive && (
                    <div className="absolute top-[60%] left-[65%] w-32 h-10 border-2 border-emerald-500 rounded bg-emerald-500/20 flex items-center justify-center shadow-[0_0_20px_rgba(16,185,129,0.4)] animate-pulse">
                        <div className="absolute -top-6 left-0 bg-emerald-500 text-black text-[10px] font-bold px-1.5 py-0.5 rounded-t">
                            CONFIANÇA: 98%
                        </div>
                        <MousePointer2 className="w-4 h-4 text-emerald-400 absolute -bottom-6 -right-6" />
                    </div>
                  )}
               </div>
            </div>

            {/* Logs Terminal */}
            <div className="flex-1 bg-[#010409] border border-slate-800 rounded-2xl p-0 overflow-hidden flex flex-col h-64">
              <div className="px-4 py-2 bg-slate-900 border-b border-slate-800 flex justify-between items-center">
                <div className="flex items-center gap-2">
                   <Terminal className="w-4 h-4 text-slate-500" />
                   <span className="text-xs font-mono text-slate-400">Logs do Sistema</span>
                </div>
                <div className="flex gap-1.5">
                  <div className="w-2.5 h-2.5 rounded-full bg-slate-700"></div>
                  <div className="w-2.5 h-2.5 rounded-full bg-slate-700"></div>
                  <div className="w-2.5 h-2.5 rounded-full bg-slate-700"></div>
                </div>
              </div>
              <div className="flex-1 overflow-y-auto p-4 font-mono text-xs space-y-1.5 scrollbar-thin">
                {logs.length === 0 && <span className="text-slate-600 italic">Sistema inicializado. Aguardando eventos...</span>}
                {logs.map((log) => (
                  <div key={log.id} className="flex gap-3">
                    <span className="text-slate-600 shrink-0">[{log.timestamp}]</span>
                    <span className={`${
                      log.type === 'error' ? 'text-red-400' : 
                      log.type === 'success' ? 'text-emerald-400' : 
                      log.type === 'warning' ? 'text-amber-400' :
                      log.type === 'bridge' ? 'text-purple-400' :
                      'text-blue-300'
                    }`}>
                      {log.type === 'bridge' ? '⚡ ' : log.type === 'error' ? '✖ ' : log.type === 'success' ? '✔ ' : '> '}
                      {log.message}
                    </span>
                  </div>
                ))}
                <div ref={logsEndRef} />
              </div>
            </div>
          </div>

          {/* Right Panel: Control & Stats */}
          <div className="col-span-4 space-y-6">
            
            {/* Safety Status Card */}
            <div className={`p-6 rounded-2xl border ${metrics.safetyLockActive ? 'bg-red-950/20 border-red-500/50 danger-glow' : 'bg-slate-900/50 border-slate-800'}`}>
              <div className="flex items-start justify-between mb-4">
                <div>
                   <h3 className="text-sm font-bold uppercase tracking-widest text-slate-400 mb-1">Conformidade de Auditoria</h3>
                   <div className="flex items-center gap-2">
                     {metrics.safetyLockActive ? <ShieldAlert className="w-5 h-5 text-red-500" /> : <ShieldCheck className="w-5 h-5 text-emerald-500" />}
                     <span className={`text-xl font-medium ${metrics.safetyLockActive ? 'text-red-500' : 'text-emerald-500'}`}>
                       {metrics.safetyLockActive ? 'VIOLAÇÃO DETECTADA' : 'SEGURO'}
                     </span>
                   </div>
                </div>
              </div>
              
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-slate-500">Limite de Alteração de Arquivos</span>
                    <span className="text-slate-300">Máx 5</span>
                  </div>
                  <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden">
                    <div 
                        className={`h-full transition-all duration-500 ${metrics.filesChangedCurrentBatch > 5 ? 'bg-red-500' : 'bg-blue-500'}`} 
                        style={{ width: `${(metrics.filesChangedCurrentBatch / 8) * 100}%` }}
                    ></div>
                  </div>
                  <div className="text-right mt-1">
                    <span className={`text-xs font-mono ${metrics.filesChangedCurrentBatch > 5 ? 'text-red-400' : 'text-slate-500'}`}>
                      {metrics.filesChangedCurrentBatch} arquivos alterados detectados
                    </span>
                  </div>
                </div>
                <p className="text-[10px] text-slate-500 leading-relaxed border-t border-slate-800 pt-3">
                  A Trava de Segurança pausa automaticamente todas as entradas automatizadas se o diff monitorado exceder 5 arquivos para evitar commits em massa não verificados.
                </p>
              </div>
            </div>

            {/* Target Config */}
            <div className="glass-panel p-6 rounded-2xl">
              <div className="flex justify-between items-center mb-4">
                 <h3 className="text-sm font-bold text-white">Assinaturas de Alvo</h3>
                 <button className="text-[10px] bg-slate-800 hover:bg-slate-700 px-2 py-1 rounded text-slate-300 transition-colors">
                   + ADICIONAR
                 </button>
              </div>
              
              <div className="space-y-3">
                {targets.map(target => (
                  <div key={target.id} className="group p-3 bg-slate-800/30 border border-slate-700/50 hover:border-slate-600 rounded-xl transition-all">
                    <div className="flex justify-between items-start mb-2">
                       <div className="flex items-center gap-2">
                          <div className="w-2 h-2 rounded-full" style={{ backgroundColor: target.color }}></div>
                          <span className="text-sm font-medium text-slate-200">{target.name}</span>
                       </div>
                       <span className={`text-[10px] px-1.5 py-0.5 rounded border ${target.status === 'active' ? 'border-emerald-500/30 text-emerald-500 bg-emerald-500/10' : 'border-slate-600 text-slate-500'}`}>
                         {target.status}
                       </span>
                    </div>
                    <div className="flex justify-between items-center text-[10px] text-slate-500 font-mono">
                       <span>OCR: "{target.triggerText}"</span>
                       <span>{target.shortcut}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Actions */}
            <div className="grid grid-cols-2 gap-4">
              <button className="p-4 bg-slate-900 border border-slate-800 rounded-xl hover:bg-slate-800 hover:border-blue-500/30 transition-all text-left group">
                <span className="block text-2xl mb-1 group-hover:scale-110 transition-transform duration-300">📸</span>
                <span className="text-xs font-semibold text-slate-400 group-hover:text-blue-400">Recalibrar Visão</span>
              </button>
              <button className="p-4 bg-slate-900 border border-slate-800 rounded-xl hover:bg-slate-800 hover:border-blue-500/30 transition-all text-left group">
                <span className="block text-2xl mb-1 group-hover:scale-110 transition-transform duration-300">📡</span>
                <span className="text-xs font-semibold text-slate-400 group-hover:text-blue-400">Testar Ponte</span>
              </button>
            </div>

          </div>
        </div>
      </main>
    </div>
  );
};

export default App;
